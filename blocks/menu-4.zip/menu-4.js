document.querySelector('.hamburger-menu').addEventListener('click', function() {
  document.querySelector('.menu-4').classList.toggle('active');
});
